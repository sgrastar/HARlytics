import{ac as o,ad as n}from"./DUPfhjc0.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
