import{bq as e,bp as n}from"../chunks/DUPfhjc0.js";export{e as component,n as universal};
